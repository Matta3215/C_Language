#include <iostream>
#include "Produto.h"

int main()
{
    Produto produto("Teclado", -150);

    std::cout << "\nProduto: "
              << produto.getNome()
              << "\n";

    std::cout << "\nPreco: "
              << produto.getPreco()
              << "\n\n";

    std::string nome{"Maria"};
    std::cout << nome[0] << "\n";
    std::cout << nome[2] << "\n";
    std::cout << nome[4] << "\n\n";

    return 0;
};