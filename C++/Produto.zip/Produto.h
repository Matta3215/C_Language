#pragma once
#include <string>

class Produto
{
private:

    std::string nome;
    double preco;

public: 
    
    Produto(const std::string& nome, const double& preco);

    std::string getNome() const;
    double getPreco() const;

    void setNome(const std::string& nome);
    void setPreco(const double& preco);
};
