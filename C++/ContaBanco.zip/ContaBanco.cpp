#include "ContaBanco.h"

//se uma das funções é trancar o codigo por trás da biblioteca, pq que eu faço as funções aqui e não no .h

ContaBanco::ContaBanco(const std::string& nome): nomeTitular{nome}
{

}

void ContaBanco::setNomeTitular(const std::string& nome)
{
    nomeTitular = nome;
}

std::string ContaBanco::getNomeTitular() const
{
    return nomeTitular;
}