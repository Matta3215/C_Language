#include <iostream>
#include "ContaBanco.h"

int main()
{
    ContaBanco conta("Maria");
    std::cout << "Titular: " 
              << conta.getNomeTitular()
              << "\n";

    conta.setNomeTitular("Joao");
    std::cout << "Novo Titular: " 
              << conta.getNomeTitular()
              << "\n";
    return 0;
};
        