#ifndef LIVRO_H
#define LIVRO_H
#include <string>

class Livro
{
private:

    std::string titulo;
    std::string autor;
    int anoPublicacao;

public:

    Livro(const std::string& tituloInicial, const std::string& autorInicial, const int& anoPublicacaoInicial);

    std::string getTitulo() const;
    std::string getAutor() const;
    int getAnoPublicacao() const;

    void setAnoPublicacao(const int& anoPublicacaoInicial);
};




#endif