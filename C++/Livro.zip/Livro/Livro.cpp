#include "Livro.h"

Livro::Livro(const std::string& tituloInicial, const std::string& autorInicial, const int& anoPublicacaoInicial)
    : titulo{tituloInicial}, 
    autor{autorInicial}, 
    anoPublicacao{0}
{
    if (anoPublicacaoInicial > 0)
    {
        anoPublicacao = anoPublicacaoInicial;
    }
}

std::string Livro::getTitulo() const
{
    return titulo;
}

std::string Livro::getAutor() const
{
    return autor;
}

int Livro::getAnoPublicacao() const
{
    return anoPublicacao;
}

void Livro::setAnoPublicacao(const int& novoAnoPublicacao)
{
    if(novoAnoPublicacao > 0)
    {
        anoPublicacao = novoAnoPublicacao;
    }
}