#include <iostream>
#include "Livro.h"

int main()
{
    Livro livro("Revolucao dos Bichos", "George Orwell", 1945);

    livro.setAnoPublicacao(-1945);

    std::cout << "\nTitulo: " << livro.getTitulo()
              << "\nAutor: " << livro.getAutor()
              << "\nAno de Publicacao: " << livro.getAnoPublicacao()
              << "\n\n";

    return 0;
};