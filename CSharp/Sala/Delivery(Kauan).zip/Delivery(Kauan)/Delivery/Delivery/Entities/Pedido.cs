﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Delivery.Entities
{
    public class Pedido
    {
        [Key]
        public int Id { get; set; }

        public int ContaId { get; set; }

        public Conta? Cliente { get; set; }

        public string? Status { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal ValorTotal { get; set; }

        public ICollection<ItensDePedido>? ItensDePedido { get; set; }
    }
}