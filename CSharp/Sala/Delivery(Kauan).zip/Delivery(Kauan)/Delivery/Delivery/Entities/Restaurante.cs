﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delivery.Entities
{
    public class Restaurante
    {
        [Key] // identifica o id como a chave
        public int Id { get; set; }

        public string RazaoSocial { get; set; }
        public string Cnpj { get; set; }

        public bool Aberto { get; set; }

        public ICollection<Produto>? Cardapio { get; set; }
        public ICollection<Pedido>? Pedidos { get; set; }

        public Restaurante()
        {
            Cardapio = new List<Produto>();
            Pedidos = new List<Pedido>();
            Aberto = false;
        }

        public void AbrirRestaurante()
        {
            Aberto = true;
        }

        public void FecharRestaurante()
        {
            Aberto = false;
        }

        public IEnumerable<Produto> ListarProdutos()
        {
            return Cardapio ?? Enumerable.Empty<Produto>();
        }

        public IEnumerable<Pedido> ListarPedidos()
        {
            return Pedidos ?? Enumerable.Empty<Pedido>();
        }

        public void AdicionarProduto(Produto produto)
        {
            if (produto == null) return;

            if (Cardapio == null)
                Cardapio = new List<Produto>();

            Cardapio.Add(produto);
        }

        public void RemoverProduto(Produto produto)
        {
            if (produto == null || Cardapio == null) return;

            if (Cardapio.Contains(produto))
                Cardapio.Remove(produto);
        }
    }
}
