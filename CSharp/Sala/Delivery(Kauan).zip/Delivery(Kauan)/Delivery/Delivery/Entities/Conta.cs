﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema; 

namespace Delivery.Entities
{
    public class Conta
    {
        [Key]
        public int Id { get; set; }

        public string? Usuario { get; set; }
        public string? Email { get; set; }
        public string? Senha { get; set; }
        public string? Endereco { get; set; }

        public ICollection<Pedido>? Pedidos { get; set; }
    }
}