﻿namespace Delivery.Entities
{
    public class Bebida : Produto
    {
        public bool Gelada { get; set; }

    }
}