﻿using Delivery.Interfaces; 

namespace Delivery.Entities
{
    public class Prato : Produto, IPreparacao
    {
        public string? Ingredientes { get; set; }
        public string? TempoPreparo { get; set; }

        public override double CalcularPreco()
        {
            return base.CalcularPreco() * 1.05;
        }

        public void Preparar()
        {
            Console.WriteLine($"Preparando prato: {this.Nome}");
        }
    }
}

