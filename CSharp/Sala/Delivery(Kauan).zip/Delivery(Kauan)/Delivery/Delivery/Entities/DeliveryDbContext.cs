﻿using Microsoft.EntityFrameworkCore;
using Delivery.Entities;

namespace Delivery.Entities
{
    public class DeliveryDbContext : DbContext
    {
        public DeliveryDbContext(DbContextOptions<DeliveryDbContext> options) : base(options) { }

        public DeliveryDbContext() { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=DBDeliveryApp;Trusted_Connection=True;");
            }
        }
        public DbSet<Conta> Contas { get; set; } = null!;
        public DbSet<Produto> Produtos { get; set; } = null!;
        public DbSet<Pedido> Pedidos { get; set; } = null!;
        public DbSet<ItensDePedido> ItensDePedidos { get; set; } = null!;

        
    }
}