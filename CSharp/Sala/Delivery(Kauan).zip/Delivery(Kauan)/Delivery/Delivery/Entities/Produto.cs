﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Delivery.Entities
{
    public class Produto
    {
        [Key]
        public int Id { get; set; }

        public string? Nome { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Preco { get; set; }

        public int QuantidadeEstoque { get; set; }
        public bool Disponibilidade { get; set; }

        public ICollection<ItensDePedido>? ItensDePedido { get; set; }
        public virtual double CalcularPreco()
        {
            return (double)this.Preco; 
        }
    }
}