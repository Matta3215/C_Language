﻿
using Delivery.Entities;
using Delivery.Interfaces; 
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Delivery.Model
{
    public class ProdutoService
    {
        private readonly DeliveryDbContext _context;

        public ProdutoService(DeliveryDbContext context)
        {
            _context = context;
        }

        public void Adicionar(Produto produto)
        {
            _context.Produtos.Add(produto);
            _context.SaveChanges();
        }

        public Produto? BuscarPorId(int id)
        {
            return _context.Produtos.Find(id);
        }

        public ICollection<Produto> BuscarTodos()
        {
            return _context.Produtos.ToList();
        }

        public void Atualizar(Produto produto)
        {
            _context.Produtos.Update(produto);
            _context.SaveChanges();
        }

        public void Remover(int id)
        {
            var produto = BuscarPorId(id);
            if (produto != null)
            {
                _context.Produtos.Remove(produto);
                _context.SaveChanges();
            }
        }

        public ICollection<Produto> BuscarDisponiveis()
        {
            return _context.Produtos
                .Where(p => p.Disponibilidade == true && p.QuantidadeEstoque > 0)
                .ToList();
        }

        public void IniciarPreparo(int produtoId)
        {
            var item = BuscarPorId(produtoId);


            if (item is Prato prato)
            {
                prato.Preparar();
            }
            else
            {
                throw new InvalidOperationException($"O produto de ID {produtoId} não pode ser preparado.");
            }
        }
    }
}