using System.Linq;
using System.Windows;
using Delivery.Entities;

namespace Delivery.View
{
    public partial class CreateAccountWindow : Window
    {
        public CreateAccountWindow()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnCriar_Click(object sender, RoutedEventArgs e)
        {
            var usuario = txtNovoUsuario.Text?.Trim();
            var email = txtEmail.Text?.Trim();
            var senha = txtNovaSenha.Password;
            var confirma = txtConfirmSenha.Password;

            if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(senha))
            {
                MessageBox.Show("Preencha todos os campos.", "Atencao", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (senha != confirma)
            {
                MessageBox.Show("As senhas nao conferem.", "Atencao", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using var context = new DeliveryDbContext();

            if (context.Contas.Any(c => c.Usuario == usuario))
            {
                MessageBox.Show("Usuario ja existe. Escolha outro.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var conta = new Conta
            {
                Usuario = usuario,
                Email = email,
                Senha = senha
            };

            context.Contas.Add(conta);
            context.SaveChanges();

            MessageBox.Show("Conta criada com sucesso.", "Sucesso", MessageBoxButton.OK, MessageBoxImage.Information);
            this.Close();
        }
    }
}
