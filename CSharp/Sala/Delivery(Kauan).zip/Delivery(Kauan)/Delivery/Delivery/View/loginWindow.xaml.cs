﻿using System.Linq;
using System.Windows;
using Delivery.Entities;

namespace Delivery.View
{
    /// <summary>
    /// Lógica interna para loginWindow.xaml
    /// </summary>
    public partial class loginWindow : Window
    {
        public loginWindow()
        {
            InitializeComponent();
        }

        private void btnProximo_Click(object sender, RoutedEventArgs e)
        {
            var usuario = txtUsuario.Text?.Trim();
            var senha = txtSenha.Password;

            if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(senha))
            {
                MessageBox.Show("Informe usuário e senha.", "Atenção", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using var context = new DeliveryDbContext();
            var conta = context.Contas.FirstOrDefault(c => c.Usuario == usuario && c.Senha == senha);

            if (conta != null)
            {
                // Abrir a janela principal se houver
                var app = (App)Application.Current;
                var mainWindow = app.Services.GetService(typeof(MainWindow)) as MainWindow;
                if (mainWindow != null)
                {
                    mainWindow.Show();
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("Usuário ou senha inválidos.", "Erro de autenticação", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnCriarConta_Click(object sender, RoutedEventArgs e)
        {
            var criar = new CreateAccountWindow();
            criar.Owner = this;
            criar.ShowDialog();
        }
    }
}
