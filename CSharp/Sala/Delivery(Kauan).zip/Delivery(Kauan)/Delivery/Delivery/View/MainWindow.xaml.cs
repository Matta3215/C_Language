﻿using Delivery.Controller;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Delivery
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly ProdutoController _produtoController;

        // O ProdutoController é injetado no construtor pelo contêiner de DI
        public MainWindow(ProdutoController produtoController)
        {
            InitializeComponent();

            // Armazenar a instância injetada
            _produtoController = produtoController;

            // Exemplo de uso:
            // var produtos = _produtoController.ListarTodos();
            // this.DataContext = produtos; 
        }
    }
}