﻿using System;
using Delivery;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Windows;
using Delivery.Controller;
using Delivery.Model;
using Delivery.Entities;
using Microsoft.EntityFrameworkCore;
using Delivery.View;

namespace Delivery
{
    public partial class App : Application
    {
        private readonly IHost _host;
        public IServiceProvider Services => _host.Services;

        public App()
        {
            _host = Host.CreateDefaultBuilder()
                .ConfigureServices((context, services) =>
                {
                    // DbContext (usar connection string do OnConfiguring para compatibilidade)
                    services.AddDbContext<DeliveryDbContext>(options =>
                    {
                        options.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=DBDeliveryApp;Trusted_Connection=True;");
                    });

                    // Serviços e controllers
                    services.AddScoped<ProdutoService>();
                    services.AddTransient<ProdutoController>();

                    // Janelas
                    services.AddSingleton<MainWindow>();
                    services.AddTransient<loginWindow>();
                    services.AddTransient<CreateAccountWindow>();
                })
                .Build();
        }

        protected override async void OnStartup(StartupEventArgs e)
        {
            await _host.StartAsync();

            // Abrir janela de login ao iniciar
            var login = Services.GetRequiredService<loginWindow>();
            login.Show();

            base.OnStartup(e);
        }

        protected override async void OnExit(ExitEventArgs e)
        {
            using (_host)
            {
                await _host.StopAsync();
            }
            base.OnExit(e);
        }
    }
}
