﻿namespace Delivery.Interfaces
{
    public interface IPreparacao
    {
        void Preparar();
    }
}