﻿
using Delivery.Entities;
using Delivery.Model;
using System.Collections.Generic;
using System;

namespace Delivery.Controller
{
    public class ProdutoController
    {
        private readonly ProdutoService _produtoService;

        public ProdutoController(ProdutoService produtoService)
        {
            _produtoService = produtoService;
        }

        public void ExibirCardapioCompleto()
        {
            ICollection<Produto> produtos = _produtoService.BuscarTodos();

            Console.WriteLine("\n--- CARDÁPIO COMPLETO (Listagem via Controller) ---");
            foreach (var p in produtos)
            {
                Console.WriteLine($"ID: {p.Id} | Nome: {p.Nome} | Tipo: {p.GetType().Name} | Preço Final: {p.CalcularPreco():C}");
            }
        }

        public bool AdicionarNovoProduto(Produto novoProduto)
        {
            if (novoProduto == null)
                return false;

            try
            {
                _produtoService.Adicionar(novoProduto);
                Console.WriteLine($"Produto '{novoProduto.Nome}' adicionado com sucesso.");

                if (novoProduto is Prato)
                {
                    _produtoService.IniciarPreparo(novoProduto.Id);
                }

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao adicionar produto: {ex.Message}");
                return false;
            }
        }

        public bool RemoverProduto(int id)
        {
            try
            {
                _produtoService.Remover(id);
                Console.WriteLine($"Produto de ID {id} removido com sucesso.");
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}